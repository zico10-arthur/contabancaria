namespace exercíciosdogemini.Domain.Entites;

public class Cliente
{
    public string Nome { get; set; }

    public string Cpf { get; set; }

    public decimal Saldo { get; set; }


}
