namespace exercíciosdogemini.Domain.Entites;

public class Database
{
    public static List<Cliente> Cliente { get; } = new();

}
