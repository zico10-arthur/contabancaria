﻿using exercíciosdogemini.Domain.Entites;
using exercíciosdogemini.presentation;


MenuDoCadastro.Mostrar();
Menu.Mostrar();

